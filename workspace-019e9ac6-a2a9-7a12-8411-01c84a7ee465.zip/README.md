# Planned by Phoebe Events — Event Planning App

A versatile, elegant web-based event planning and management application built for **Planned by Phoebe Events**.

**Primary brand colors:** Pink (#DB2777) and Gold (#D97706)  
**Currency:** Ghana Cedis (GHS)

## Features

- **Dashboard**: Overview with key metrics, upcoming events, recent activity, and quick stats.
- **My Events**: Full CRUD for events. Cards with budgets, progress, guests, status filters, and search.
- **Tasks**: Task management with status tracking (To Do / In Progress / Done), linked to events, due dates, assignees.
- **Budget & Expenses**: Track planned budgets vs actual spending in GHS. Log expenses by category, vendor, and event. CSV export.
- **Vendors**: Manage supplier network with services, quoted prices, contacts.
- **Calendar**: Monthly view with event indicators + list of events for the month.
- **Reports**: Visual insights with interactive charts (Budget allocation, status breakdown, monthly spend trend).
- **Event Detail Modal**: Deep dive into each event with tabs for Overview, Tasks, Expenses, Guests (RSVP tracking).
- **Additional**: Global search, printable PDF reports, full data export/import, local persistence.

## How to Use

1. Open `index.html` in any modern browser (Chrome, Firefox, Safari, Edge).
2. The app runs entirely in the browser. All data is saved to your browser's localStorage.
3. Start by creating events using the **New Event** button (or the pink + FAB on mobile).
4. Add tasks, log expenses, manage vendors, and track guests per event.

### Mobile Phone / PWA Installation (Recommended)

This app is now a **Progressive Web App (PWA)** — it works great on phones and can be installed like a native app:

**On Android (Chrome):**
- Open the site in Chrome
- Tap the menu (⋮) → "Install app" or "Add to home screen"
- Or look for the **Install** button in the bottom navigation

**On iPhone (Safari):**
- Open in Safari
- Tap the Share button (square with arrow)
- Scroll down and tap "Add to Home Screen"
- It will appear on your home screen with the pink/gold icon

Once installed:
- Works offline
- Full-screen experience (no browser UI)
- Receives the pink theme color in the status bar
- Faster loading

**Files added for mobile:**
- `manifest.json`
- `service-worker.js`
- `icons/` folder with app icons
- Floating Action Button (FAB) + improved bottom nav for phones

## Data Persistence

- Everything is stored locally in your browser.
- Use **Settings** (cog icon in sidebar) to:
  - Export your full data as JSON for backup
  - Import data from another device
  - Load Sample / Demo Data
  - Reset All Data (completely clears everything)

The app now launches with a clean slate by default.

## Sample Data

The app now starts **completely empty** (no pre-loaded data).

You can load realistic demo data anytime from **Settings** (cog icon) → "Load Sample / Demo Data".

The demo includes weddings, corporate galas, charity events, tasks, expenses, and vendors.

## Technical Notes

- Built with vanilla HTML + Tailwind CSS (via CDN) + Chart.js
- Fully responsive (desktop sidebar + mobile bottom nav)
- All monetary values displayed in Ghana Cedis with proper formatting
- Date handling set around June 2026 (matches current simulated date)

## Customization

- Colors are defined in the `<style>` block and Tailwind config in JS.
- To add new categories or change defaults, edit the relevant select options in the HTML.

**Created for Planned by Phoebe Events** — Luxury event planning in Ghana.

Enjoy planning unforgettable moments! ✨

---

## Connect to Repository & Deployment

The project is already initialized as a Git repository with the latest logo and all features.

### Step 1: Connect to GitHub (or your preferred Git host)

1. Create a new repository on GitHub (do **not** initialize with README, .gitignore, or license).
2. On your local machine (or download the workspace files), run these commands:

```bash
git remote add origin https://github.com/YOUR_USERNAME/planned-by-phoebe-events.git
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

### Step 2: Deploy (Recommended Options)

#### Option A: GitHub Pages (Free & Simple)

1. Go to your GitHub repo → **Settings** → **Pages**.
2. Under "Source", select **Deploy from a branch** → Branch: `main` → Folder: `/ (root)`.
3. Save. Your site will be live at:
   `https://YOUR_USERNAME.github.io/planned-by-phoebe-events`

**Note:** For the PWA to work perfectly on GitHub Pages, you may need to set the custom domain or just use the provided URL.

#### Option B: Netlify (Best for PWAs - Recommended)

1. Go to [netlify.com](https://netlify.com) and sign up (free).
2. Click **"Add new site"** → **"Import an existing project"**.
3. Connect your GitHub account and select the repo.
4. Netlify will auto-detect it's a static site.
5. Click **Deploy site**.
6. Your app will be live instantly (e.g. `https://amazing-unicorn-123.netlify.app`).

**Advantages:** Automatic deploys on every push, excellent PWA support, free SSL, custom domain easy.

#### Option C: Vercel (Also Excellent)

1. Go to [vercel.com](https://vercel.com) → Sign up with GitHub.
2. Import the repository.
3. Deploy (zero config needed for static HTML).

### After Deployment

- Test the PWA: Open on mobile → Add to Home Screen.
- The logo you attached is used for both the navbar and the installable app icon.
- All data remains private on the user's device (localStorage).

### Updating the App

Just edit files and push to your repo:
```bash
git add .
git commit -m "Update logo and features"
git push
```

The hosting platform will automatically redeploy.

---

**Project Structure**
- `index.html` — Main app
- `logo.png` — Your attached logo (used in navbar + reports)
- `manifest.json` + `service-worker.js` — PWA support
- `icons/` — App icons for mobile install
- `README.md` — This file

Enjoy your deployed app! If you share the live URL later, I can help with further improvements. 🎀
